<?php require_once __DIR__.'/includes/auth.php';auth_logout();header('Location: '.base_url('index.php'));exit;
