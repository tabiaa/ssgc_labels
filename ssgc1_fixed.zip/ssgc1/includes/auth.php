<?php
require_once __DIR__ . '/db.php';
function session_start_safe(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off']);
        session_start();
    }
    if (!empty($_SESSION['user']) && !empty($_SESSION['last_activity']) && time()-$_SESSION['last_activity'] > SESSION_TIMEOUT) {
        $_SESSION=[]; session_destroy();
        header('Location: '.base_url('index.php?expired=1')); exit;
    }
    if (!empty($_SESSION['user'])) $_SESSION['last_activity']=time();
}
function auth_login(string $username,string $password): array|false {
    $s=db()->prepare('SELECT * FROM users WHERE username=? AND is_active=1 LIMIT 1'); $s->execute([$username]); $u=$s->fetch();
    return ($u && password_verify($password,$u['password'])) ? $u : false;
}
function auth_user(): ?array { session_start_safe(); return $_SESSION['user'] ?? null; }
function require_login(): array { $u=auth_user(); if(!$u){header('Location: '.base_url('index.php'));exit;} return $u; }
function require_role(string $role): array { $u=require_login(); if($u['role']!==$role){header('Location: '.base_url('index.php'));exit;} return $u; }
function auth_logout(): void { session_start_safe(); $_SESSION=[]; if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$p['path'],'domain'=>$p['domain'],'secure'=>$p['secure'],'httponly'=>$p['httponly'],'samesite'=>$p['samesite']??'Lax']); } session_destroy(); }
function base_url(string $path=''): string { $proto=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http'; $host=$_SERVER['HTTP_HOST']??'localhost'; $script=$_SERVER['SCRIPT_NAME']??'/index.php'; $base=rtrim(dirname($script),'/\\'); $parts=explode('/',trim($base,'/')); if(in_array(end($parts),['admin','operator'])) array_pop($parts); $base='/'.implode('/',$parts); return $proto.'://'.$host.rtrim($base,'/').'/'.ltrim($path,'/'); }
function csrf_token(): string { session_start_safe(); if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_verify(): void { session_start_safe(); if(!hash_equals($_SESSION['csrf']??'',$_POST['_csrf']??'')){http_response_code(403);exit('CSRF validation failed.');} }
function e(string $s): string { return htmlspecialchars($s,ENT_QUOTES,'UTF-8'); }

function set_flash(string $type, string $message): void {
    session_start_safe();
    $_SESSION['flash'] = [$type, $message];
}

function take_flash(): ?array {
    session_start_safe();
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($flash) && count($flash) >= 2 ? [$flash[0], $flash[1]] : null;
}
