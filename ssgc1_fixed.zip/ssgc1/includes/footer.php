</div></main></div><footer class="footer">SSGC Meter Label Control System · <?=date('Y')?></footer></body></html>
