<?php
// Edit these values for your IIS/MySQL installation.
define('DB_HOST', 'localhost');
define('DB_NAME', 'ssgc_labels');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');
define('APP_NAME', 'SSGC Meter Label Control System');
define('SESSION_NAME', 'ssgc_meter_label');
define('SESSION_TIMEOUT', 1800);
date_default_timezone_set('Asia/Karachi');
