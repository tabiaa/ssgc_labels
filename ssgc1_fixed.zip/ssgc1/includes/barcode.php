<?php
/** Code 128-B barcode rendered directly as SVG rectangles. No external JS/library. */
function code128_svg(string $text, float $x, float $y, float $width, float $height): string {
    $patterns = [
        '212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232','2331112'
    ];
    $values = [104];
    $sum = 104;
    $pos = 1;
    $len = strlen($text);
    for ($i=0; $i<$len; $i++) {
        $o = ord($text[$i]);
        if ($o < 32 || $o > 127) throw new InvalidArgumentException('Code 128-B supports ASCII 32-127 only.');
        $v = $o - 32;
        $values[] = $v;
        $sum += $v * $pos++;
    }
    $values[] = $sum % 103;
    $values[] = 106;
    $modules = 0;
    foreach ($values as $v) foreach (str_split($patterns[$v]) as $n) $modules += (int)$n;
    $module = $width / $modules;
    $cursor = $x;
    $black = true;
    $out = '<g shape-rendering="crispEdges">';
    foreach ($values as $v) {
        foreach (str_split($patterns[$v]) as $n) {
            $w = (int)$n * $module;
            if ($black) {
                $out .= '<rect x="'.rtrim(rtrim(number_format($cursor,3,'.',''),'0'),'.').'" y="'.rtrim(rtrim(number_format($y,3,'.',''),'0'),'.').'" width="'.rtrim(rtrim(number_format($w,3,'.',''),'0'),'.').'" height="'.rtrim(rtrim(number_format($height,3,'.',''),'0'),'.').'" fill="#000"/>';
            }
            $cursor += $w;
            $black = !$black;
        }
    }
    return $out.'</g>';
}
