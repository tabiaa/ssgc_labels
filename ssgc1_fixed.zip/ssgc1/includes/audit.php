<?php
require_once __DIR__.'/db.php';
function audit(?int $user,string $action,?string $entity=null,?int $id=null,string $details=''):void{db()->prepare('INSERT INTO audit_log(user_id,action,entity_type,entity_id,details,ip_address) VALUES(?,?,?,?,?,?)')->execute([$user,$action,$entity,$id,$details,$_SERVER['REMOTE_ADDR']??null]);}
