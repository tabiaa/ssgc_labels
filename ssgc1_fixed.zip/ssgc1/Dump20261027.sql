-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssgc_labels
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_audit_created` (`created_at`),
  CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES (1,1,'USER_CREATED','user',2,'op1','::1','2026-09-23 10:13:23'),(2,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',1,'A 100-100','::1','2026-09-23 10:13:39'),(3,2,'PRINT_PAGE_OPENED','print_job',1,'original','::1','2026-09-23 10:13:39'),(4,2,'REPRINT_REQUEST','reprint_request',1,'xyz','::1','2026-09-23 10:16:25'),(5,1,'PASSWORD_RESET','user',2,'','::1','2026-09-23 15:43:02'),(6,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',2,'A 102-102','::1','2026-09-23 15:43:48'),(7,2,'PRINT_PAGE_OPENED','print_job',2,'original','::1','2026-09-23 15:43:48'),(8,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',3,'A 103-103','::1','2026-09-23 15:45:26'),(9,2,'PRINT_PAGE_OPENED','print_job',3,'original','::1','2026-09-23 15:45:26'),(10,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',4,'A 105-105','::1','2026-09-24 08:33:31'),(11,2,'PRINT_PAGE_OPENED','print_job',4,'original','::1','2026-09-24 08:33:31'),(12,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',5,'B 105-105','::1','2026-09-24 08:37:33'),(13,2,'PRINT_PAGE_OPENED','print_job',5,'original','::1','2026-09-24 08:37:33'),(14,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',6,'Z 100-100','::1','2026-09-24 09:02:25'),(15,2,'PRINT_PAGE_OPENED','print_job',6,'original','::1','2026-09-24 09:02:25'),(16,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',7,'X 100-100','::1','2026-09-24 09:02:41'),(17,2,'PRINT_PAGE_OPENED','print_job',7,'original','::1','2026-09-24 09:02:41'),(18,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',8,'Y 100-100','::1','2026-09-24 09:06:50'),(19,2,'PRINT_PAGE_OPENED','print_job',8,'original','::1','2026-09-24 09:06:50'),(20,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',9,'T 100-100','::1','2026-09-24 09:15:10'),(21,2,'PRINT_PAGE_OPENED','print_job',9,'original','::1','2026-09-24 09:15:10'),(22,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',10,'E 100-100','::1','2026-09-24 09:15:45'),(23,2,'PRINT_PAGE_OPENED','print_job',10,'original','::1','2026-09-24 09:15:45'),(24,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',11,'W 100-100','::1','2026-09-24 09:16:32'),(25,2,'PRINT_PAGE_OPENED','print_job',11,'original','::1','2026-09-24 09:16:32'),(26,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',12,'C 100-100','::1','2026-09-24 09:19:16'),(27,2,'PRINT_PAGE_OPENED','print_job',12,'original','::1','2026-09-24 09:19:16'),(28,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',13,'D 100-100','::1','2026-09-24 09:21:03'),(29,2,'PRINT_PAGE_OPENED','print_job',13,'original','::1','2026-09-24 09:21:03'),(30,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',14,'H 100-100','::1','2026-09-24 09:21:50'),(31,2,'PRINT_PAGE_OPENED','print_job',14,'original','::1','2026-09-24 09:21:50'),(32,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',15,'J 100-100','::1','2026-09-24 09:23:02'),(33,2,'PRINT_PAGE_OPENED','print_job',15,'original','::1','2026-09-24 09:23:02'),(34,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',16,'L 100-100','::1','2026-09-24 09:23:40'),(35,2,'PRINT_PAGE_OPENED','print_job',16,'original','::1','2026-09-24 09:23:40'),(36,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',17,'K 100-100','::1','2026-10-05 09:09:13'),(37,2,'PRINT_PAGE_OPENED','print_job',17,'original','::1','2026-10-05 09:09:13'),(38,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',18,'P 100-100','::1','2026-10-05 09:11:53'),(39,2,'PRINT_PAGE_OPENED','print_job',18,'original','::1','2026-10-05 09:11:53'),(40,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',19,'R 100-100','::1','2026-10-05 09:12:15'),(41,2,'PRINT_PAGE_OPENED','print_job',19,'original','::1','2026-10-05 09:12:15'),(42,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',20,'I 100-100','::1','2026-10-05 09:21:17'),(43,2,'PRINT_PAGE_OPENED','print_job',20,'original','::1','2026-10-05 09:21:17'),(44,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',21,'Q 100-100','::1','2026-10-05 09:21:35'),(45,2,'PRINT_PAGE_OPENED','print_job',21,'original','::1','2026-10-05 09:21:35'),(46,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',22,'A 101-101','::1','2026-10-05 09:24:06'),(47,2,'PRINT_PAGE_OPENED','print_job',22,'original','::1','2026-10-05 09:24:06'),(48,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',23,'Q 105-105','::1','2026-10-13 10:29:39'),(49,2,'PRINT_PAGE_OPENED','print_job',23,'original','::1','2026-10-13 10:29:39'),(50,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',24,'A 109-109','::1','2026-10-13 10:30:02'),(51,2,'PRINT_PAGE_OPENED','print_job',24,'original','::1','2026-10-13 10:30:02'),(52,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',25,'A 120-120','::1','2026-10-13 10:32:04'),(53,2,'PRINT_PAGE_OPENED','print_job',25,'original','::1','2026-10-13 10:32:04'),(54,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',26,'A 200-200','::1','2026-10-13 10:33:36'),(55,2,'PRINT_PAGE_OPENED','print_job',26,'original','::1','2026-10-13 10:33:36'),(56,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',27,'B 200-200','::1','2026-10-13 10:33:54'),(57,2,'PRINT_PAGE_OPENED','print_job',27,'original','::1','2026-10-13 10:33:54'),(58,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',28,'A 201-201','::1','2026-10-13 10:35:51'),(59,2,'PRINT_PAGE_OPENED','print_job',28,'original','::1','2026-10-13 10:35:51'),(60,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',29,'B 201-201','::1','2026-10-13 10:42:28'),(61,2,'PRINT_PAGE_OPENED','print_job',29,'original','::1','2026-10-13 10:42:28'),(62,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',30,'C 201-201','::1','2026-10-13 11:03:37'),(63,2,'PRINT_PAGE_OPENED','print_job',30,'original','::1','2026-10-13 11:03:37'),(64,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',31,'A 300-300','::1','2026-10-26 15:49:08'),(65,2,'PRINT_PAGE_OPENED','print_job',31,'original','::1','2026-10-26 15:49:08'),(66,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',32,'A 301-301','::1','2026-10-27 08:47:53'),(67,2,'PRINT_PAGE_OPENED','print_job',32,'original','::1','2026-10-27 08:47:54'),(68,2,'ORIGINAL_PRINT_AUTHORIZED','print_job',33,'A 400-400','::1','2026-10-27 10:07:41'),(69,2,'PRINT_PAGE_OPENED','print_job',33,'original','::1','2026-10-27 10:07:41');
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_jobs`
--

DROP TABLE IF EXISTS `print_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `print_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `operator_id` int(10) unsigned NOT NULL,
  `label_type` enum('G4','G16') COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `range_start` smallint(5) unsigned NOT NULL,
  `range_end` smallint(5) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `print_kind` enum('original','reprint') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `error_message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `printed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `operator_id` (`operator_id`),
  KEY `ix_jobs_created` (`created_at`),
  KEY `ix_jobs_status` (`status`),
  CONSTRAINT `print_jobs_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_jobs`
--

LOCK TABLES `print_jobs` WRITE;
/*!40000 ALTER TABLE `print_jobs` DISABLE KEYS */;
INSERT INTO `print_jobs` VALUES (1,2,'G4','A',100,100,2026,'original','completed',NULL,NULL,'2026-09-23 10:13:39',NULL),(2,2,'G4','A',102,102,2026,'original','completed',NULL,NULL,'2026-09-23 15:43:48',NULL),(3,2,'G16','A',103,103,2026,'original','completed',NULL,NULL,'2026-09-23 15:45:26',NULL),(4,2,'G4','A',105,105,2026,'original','completed',NULL,NULL,'2026-09-24 08:33:31',NULL),(5,2,'G16','B',105,105,2026,'original','completed',NULL,NULL,'2026-09-24 08:37:33',NULL),(6,2,'G4','Z',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:02:25',NULL),(7,2,'G16','X',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:02:41',NULL),(8,2,'G4','Y',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:06:50',NULL),(9,2,'G4','T',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:15:10',NULL),(10,2,'G16','E',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:15:45',NULL),(11,2,'G4','W',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:16:32',NULL),(12,2,'G4','C',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:19:16',NULL),(13,2,'G4','D',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:21:03',NULL),(14,2,'G4','H',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:21:50',NULL),(15,2,'G4','J',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:23:02',NULL),(16,2,'G16','L',100,100,2026,'original','completed',NULL,NULL,'2026-09-24 09:23:40',NULL),(17,2,'G16','K',100,100,2026,'original','completed',NULL,NULL,'2026-10-05 09:09:13',NULL),(18,2,'G4','P',100,100,2026,'original','completed',NULL,NULL,'2026-10-05 09:11:53',NULL),(19,2,'G16','R',100,100,2026,'original','completed',NULL,NULL,'2026-10-05 09:12:15',NULL),(20,2,'G4','I',100,100,2026,'original','completed',NULL,NULL,'2026-10-05 09:21:17',NULL),(21,2,'G16','Q',100,100,2026,'original','completed',NULL,NULL,'2026-10-05 09:21:35',NULL),(22,2,'G16','A',101,101,2026,'original','completed',NULL,NULL,'2026-10-05 09:24:06',NULL),(23,2,'G4','Q',105,105,2026,'original','completed',NULL,NULL,'2026-10-13 10:29:39',NULL),(24,2,'G16','A',109,109,2026,'original','completed',NULL,NULL,'2026-10-13 10:30:02',NULL),(25,2,'G16','A',120,120,2026,'original','completed',NULL,NULL,'2026-10-13 10:32:04',NULL),(26,2,'G16','A',200,200,2026,'original','completed',NULL,NULL,'2026-10-13 10:33:36',NULL),(27,2,'G16','B',200,200,2026,'original','completed',NULL,NULL,'2026-10-13 10:33:54',NULL),(28,2,'G16','A',201,201,2026,'original','completed',NULL,NULL,'2026-10-13 10:35:51',NULL),(29,2,'G16','B',201,201,2026,'original','completed',NULL,NULL,'2026-10-13 10:42:28',NULL),(30,2,'G4','C',201,201,2026,'original','completed',NULL,NULL,'2026-10-13 11:03:37',NULL),(31,2,'G4','A',300,300,2026,'original','completed',NULL,NULL,'2026-10-26 15:49:08',NULL),(32,2,'G4','A',301,301,2026,'original','completed',NULL,NULL,'2026-10-27 08:47:53',NULL),(33,2,'G4','A',400,400,2026,'original','completed',NULL,NULL,'2026-10-27 10:07:41',NULL);
/*!40000 ALTER TABLE `print_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printed_serials`
--

DROP TABLE IF EXISTS `printed_serials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `printed_serials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint(20) unsigned NOT NULL,
  `serial` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `state` enum('printed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'printed',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_meter_year` (`serial`,`year`),
  KEY `job_id` (`job_id`),
  KEY `ix_serial_year` (`year`,`serial`),
  CONSTRAINT `printed_serials_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `print_jobs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printed_serials`
--

LOCK TABLES `printed_serials` WRITE;
/*!40000 ALTER TABLE `printed_serials` DISABLE KEYS */;
INSERT INTO `printed_serials` VALUES (1,1,'A0100',2026,'printed','2026-09-23 10:13:39'),(2,2,'A0102',2026,'printed','2026-09-23 15:43:48'),(3,3,'A0103',2026,'printed','2026-09-23 15:45:26'),(4,4,'A0105',2026,'printed','2026-09-24 08:33:31'),(5,5,'B0105',2026,'printed','2026-09-24 08:37:33'),(6,6,'Z0100',2026,'printed','2026-09-24 09:02:25'),(7,7,'X0100',2026,'printed','2026-09-24 09:02:41'),(8,8,'Y0100',2026,'printed','2026-09-24 09:06:50'),(9,9,'T0100',2026,'printed','2026-09-24 09:15:10'),(10,10,'E0100',2026,'printed','2026-09-24 09:15:45'),(11,11,'W0100',2026,'printed','2026-09-24 09:16:32'),(12,12,'C0100',2026,'printed','2026-09-24 09:19:16'),(13,13,'D0100',2026,'printed','2026-09-24 09:21:03'),(14,14,'H0100',2026,'printed','2026-09-24 09:21:50'),(15,15,'J0100',2026,'printed','2026-09-24 09:23:02'),(16,16,'L0100',2026,'printed','2026-09-24 09:23:40'),(17,17,'K0100',2026,'printed','2026-10-05 09:09:13'),(18,18,'P0100',2026,'printed','2026-10-05 09:11:53'),(19,19,'R0100',2026,'printed','2026-10-05 09:12:15'),(20,20,'I0100',2026,'printed','2026-10-05 09:21:17'),(21,21,'Q0100',2026,'printed','2026-10-05 09:21:35'),(22,22,'A0101',2026,'printed','2026-10-05 09:24:06'),(23,23,'Q0105',2026,'printed','2026-10-13 10:29:39'),(24,24,'A0109',2026,'printed','2026-10-13 10:30:02'),(25,25,'A0120',2026,'printed','2026-10-13 10:32:04'),(26,26,'A0200',2026,'printed','2026-10-13 10:33:36'),(27,27,'B0200',2026,'printed','2026-10-13 10:33:54'),(28,28,'A0201',2026,'printed','2026-10-13 10:35:51'),(29,29,'B0201',2026,'printed','2026-10-13 10:42:28'),(30,30,'C0201',2026,'printed','2026-10-13 11:03:37'),(31,31,'A0300',2026,'printed','2026-10-26 15:49:08'),(32,32,'A0301',2026,'printed','2026-10-27 08:47:53'),(33,33,'A0400',2026,'printed','2026-10-27 10:07:41');
/*!40000 ALTER TABLE `printed_serials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reprint_requests`
--

DROP TABLE IF EXISTS `reprint_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reprint_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `operator_id` int(10) unsigned NOT NULL,
  `label_type` enum('G4','G16') COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `range_start` smallint(5) unsigned NOT NULL,
  `range_end` smallint(5) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `reason` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','approved','rejected','used') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `admin_note` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `operator_id` (`operator_id`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `ix_rr_status` (`status`,`requested_at`),
  CONSTRAINT `reprint_requests_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`),
  CONSTRAINT `reprint_requests_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reprint_requests`
--

LOCK TABLES `reprint_requests` WRITE;
/*!40000 ALTER TABLE `reprint_requests` DISABLE KEYS */;
INSERT INTO `reprint_requests` VALUES (1,2,'G4','A',100,100,2026,'xyz','pending',NULL,NULL,NULL,'2026-09-23 10:16:25');
/*!40000 ALTER TABLE `reprint_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','operator') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'operator',
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$10$8NRbOibxBlK2W65kaCR5KuIMhovrTQMfDkHmmta/AKKqiv6FToLj2','admin','tabia alam',1,'2026-09-23 10:11:18'),(2,'op1','$2y$10$vab9p5OiFIMR9JPuEkEuyOojgWJz0cGj9AyL1kdf55R7frQh4yoq6','operator','tabia alam',1,'2026-09-23 10:13:23');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-27 15:32:51
