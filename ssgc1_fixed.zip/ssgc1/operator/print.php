<?php
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/labels.php';
require_once __DIR__.'/../includes/audit.php';
require_once __DIR__.'/../includes/barcode.php';

$u = require_role('operator');
$job = (int)($_GET['job'] ?? 0);

$q = db()->prepare('SELECT pj.*,u.full_name FROM print_jobs pj JOIN users u ON u.id=pj.operator_id WHERE pj.id=? AND pj.operator_id=? LIMIT 1');
$q->execute([$job,$u['id']]);
$j = $q->fetch();
if (!$j) { http_response_code(404); exit('Print job not found.'); }

$q = db()->prepare('SELECT serial FROM printed_serials WHERE job_id=? ORDER BY id');
$q->execute([$job]);
$serialList = array_column($q->fetchAll(),'serial');
if (!$serialList && $j['print_kind']==='reprint') {
    $serialList = serials($j['prefix'],(int)$j['range_start'],(int)$j['range_end']);
}
audit($u['id'],'PRINT_PAGE_OPENED','print_job',$job,$j['print_kind']);

function svg_text(string $text, float $x, float $y, float $size, string $weight='700', string $anchor='start', ?float $len=null, float $thin=0.0): string {
    $fit = $len !== null ? ' textLength="'.$len.'" lengthAdjust="spacingAndGlyphs"' : '';
    // $thin > 0 draws a thin white outline over the glyphs, which makes the text visibly lighter when printed.
    $thinAttr = $thin > 0 ? ' stroke="#fff" stroke-width="'.$thin.'" stroke-linejoin="round"' : '';
    return '<text x="'.$x.'" y="'.$y.'" text-anchor="'.$anchor.'" font-family="Arial Narrow,Arial,sans-serif" font-size="'.$size.'px" font-weight="'.$weight.'"'.$thinAttr.$fit.'>'.htmlspecialchars($text,ENT_QUOTES,'UTF-8').'</text>';
}

function logo_svg(float $x, float $y, float $w, float $h): string {
    // Use the actual SSGC logo artwork as a bundled raster image, not a hand-drawn SVG.
    $file = __DIR__.'/../assets/img/ssgc-logo.png';
    $data = is_file($file) ? base64_encode(file_get_contents($file)) : '';
    if (!$data) return '';
    return '<image x="'.$x.'" y="'.$y.'" width="'.$w.'" height="'.$h.'" href="data:image/png;base64,'.$data.'" preserveAspectRatio="xMidYMid meet" />';
}

function logo_flame_svg(float $x, float $y, float $w, float $h): string {
    // Black-and-white SSGC flame (embedded), so it prints solid instead of as dithered dots.
    return '<image x="'.$x.'" y="'.$y.'" width="'.$w.'" height="'.$h.'" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD8AAABkAQAAAAAZbdVGAAABS0lEQVR42m3TwZHVQAwE0Gd9V61v3xGwDoEjJ8pHwiAEIgCHQiguIjEZmNs/uEYcxrN4dzmp3ZJKPS1Z5sGPLMEBgkcDGthZCbbGrJeaDZl4znLpygYKduKccHY9iHOUwEcHYW/M5gvIVdFlCWvXncVBIt1ykSXozRaRBpNVMBrbrMEmiklfmVnYxXHqCOhgl5nLrUT9LBcT9sCcJzMRWw+WyoyEAawx8dNgs97zng8fAg+9PdYxj/bkUsFUEo+r4YclCLN/S1k7RzS/o8olLPvrfZGrp1wu4her49VOO5ddlDfrru4Gy7tLqLGChZjT/2vEVGMf27vU8xtmqEfiqnmscYxTxUtqiiGqxMbMjs/47jy/8pLqRBsfLVxM+IOjb8xwfcWCxyh8uprwbbqe8QRrvfDuN2FsqaeZX2dX9Mjjq9u9/SAjIUY3/AWpo27QQYkqzgAAAABJRU5ErkJggg==" preserveAspectRatio="xMidYMid meet" />';
}

function svg_g4(string $serial, int $year): string {
    // Layout measured from the scanned correct G-4 print (mm, label orientation).
    // Fine-tune the whole G-4 print against the die cut here:
    // +$dx moves everything toward the right of the finished label, +$dy moves everything down.
    $dx = 0.0;
    $dy = 0.0;
    $barcode = code128_svg($serial, 30.4, 30.7, 20.2, 5.4);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 104.1 130" width="104.1mm" height="130mm">'
        .'<g transform="translate(0 130) rotate(-90)">'
        .'<rect width="130" height="104.1" fill="#fff"/>'
        .'<line x1="129.15" y1="20" x2="129.15" y2="104.1" stroke="#000" stroke-width="0.45"/>'
        .'<g transform="translate('.$dx.' '.$dy.')">'
        .'<rect x="69.0" y="20.3" width="4.4" height="3.9" fill="#000"/>'
        .$barcode
        .svg_text('No.',29.9,39.9,3.75)
        .svg_text($serial,34.7,40.2,4.5)
        .svg_text('SUI SOUTHERN GAS CO.LTD.',52.8,36.2,4.2,'700','start',51.3)
        .svg_text('m',68.0,40.2,4.2,'700')
        .svg_text('3',71.0,38.6,2.3,'700')
        .svg_text('G-4',22.6,48.4,3.85,'700','middle')
        .svg_text('GAS METER',22.2,52.7,4.0,'700','middle',16.7)
        .logo_flame_svg(14.6,54.6,3.3,5.3)
        .svg_text('SSGC',16.15,63.3,3.5,'700','middle',6.7)
        .svg_text('MADE IN',12.7,69.4,4.05,'700','start',12.3)
        .svg_text('PAKISTAN',12.7,73.8,4.1,'700','start',14.1)
        .svg_text('*Qmax',69.5,54.4,3.0,'400','start',6.8,0.14)
        .svg_text('= 6 m³ /hr',77.5,54.4,3.0,'400','start',11.4,0.14)
        .svg_text('Qmin',70.3,57.9,3.0,'400','start',5.4,0.14)
        .svg_text('= 0.04 m³/hr',77.8,57.9,3.0,'400','start',13.9,0.14)
        .svg_text('Pmax',70.3,61.4,3.0,'400','start',5.9,0.14)
        .svg_text('= 0.5 bar',78.3,61.4,3.0,'400','start',10.1,0.14)
        .svg_text('C.V.',70.3,64.8,3.0,'400','start',4.2,0.14)
        .svg_text('= 1.2 dm³',78.9,64.8,3.0,'400','start',11.0,0.14)
        .'<rect x="102.2" y="44.4" width="12.05" height="4.65" fill="#fff" stroke="#000" stroke-width="0.45"/>'
        .svg_text((string)$year,108.45,48.4,3.8,'700','middle')
        .'</g>'
        .'</g></svg>';
}

function svg_g16(string $serial, int $year): string {
    $barcode = code128_svg($serial, 15.0, 44.0, 27.0, 7.0);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 90" width="80mm" height="90mm">'
        .'<g transform="translate(0 90) rotate(-90)">'
        .'<rect width="90" height="80" fill="#fff"/>'
        .'<line x1="89.2" y1="12" x2="89.2" y2="80" stroke="#000" stroke-width="0.45"/>'
        .logo_svg(10.8,22.5,5.8,8.0)
        .svg_text('SUI SOUTHERN GAS CO.LTD.',20.0,27.0,4.65)
        .svg_text('G1.6 GAS METER  '.$year.'  MADE IN PAKISTAN',20.0,32.5,3.25)
        // Open rectangular volume marking from the original label.
        .'<path d="M48 34.5 H74.5 V42.2 H48" fill="none" stroke="#000" stroke-width="1.05"/>'
        .svg_text('m³',45.0,46.0,3.5,'700')
        .$barcode
        .svg_text('No. '.$serial,15.0,55.1,3.15)
        // Compact the specification block so the final C.V. line remains inside the cut area.
        .svg_text('Qmax = 2.5 m³/hr',51.0,45.2,2.45,'400')
        .svg_text('Qmin = 0.016 m³/hr',51.0,48.2,2.45,'400')
        .svg_text('Pmax = 0.5 bar',51.0,51.2,2.45,'400')
        .svg_text('C.V. = 0.8 dm³',51.0,54.2,2.45,'400')
        .'</g></svg>';
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Print Job #<?=e((string)$job)?></title>
<link rel="stylesheet" href="<?=e(base_url('assets/css/main.css'))?>">
<style>@page{size:<?= $j['label_type']==='G4' ? '104.1mm 130mm' : '80mm 90mm' ?>;margin:0}</style>
<style>
html,body{margin:0;padding:0}
body{background:#f1f3f5}
.print-toolbar{max-width:1100px;margin:20px auto;padding:16px 20px;background:#fff;border:1px solid #ddd;border-radius:10px;display:flex;align-items:center;justify-content:space-between;gap:20px}
.print-area{display:flex;flex-direction:column;align-items:center;gap:12px;padding:20px}
.screen-note{max-width:1100px;margin:0 auto 10px;color:#555;font:13px Arial}
/* Label box is 0.2mm shorter than the page so rounding can never push content onto a blank extra page. */
.label-page{background:#fff;position:relative;overflow:hidden;break-inside:avoid;page-break-inside:avoid;break-after:page;page-break-after:always}
.label-page svg{display:block;shape-rendering:geometricPrecision;text-rendering:geometricPrecision}
.label-page.g4{width:104.1mm;height:129.8mm}
.label-page.g16{width:80mm;height:89.8mm}
@media print{
  body{background:#fff}
  .print-toolbar,.screen-note{display:none!important}
  .print-area{display:block;padding:0}
  .label-page{margin:0!important;box-shadow:none!important}
  .label-page:last-child{break-after:auto;page-break-after:auto}
}
</style></head><body>
<div class="print-toolbar"><div><strong>Print Job #<?=e((string)$job)?></strong><div style="font-size:12px;color:#667;margin-top:4px"><?=e($j['label_type'])?> · <?=e($j['prefix'].str_pad($j['range_start'],4,'0',STR_PAD_LEFT).' – '.$j['prefix'].str_pad($j['range_end'],4,'0',STR_PAD_LEFT))?> · <?=$j['year']?></div></div><div style="display:flex;gap:8px"><button class="btn btn-primary" onclick="window.print()">Print Labels</button><a class="btn btn-ghost" href="<?=e(base_url('operator/dashboard.php'))?>">Back</a></div></div>
<div class="screen-note">Select <strong>TSC TA210</strong>. Set scaling to <strong>100% / Actual Size</strong>, margins <strong>None</strong>, and turn browser headers/footers off. The page is portrait, matching the original PDF print orientation; the label artwork is rotated 90° counter-clockwise inside the page. The barcode is now generated server-side as vector bars inside the SVG.</div>
<div class="print-area">
<?php foreach ($serialList as $serial): ?>
<div class="label-page <?=$j['label_type']==='G4'?'g4':'g16'?>"><?= $j['label_type']==='G4' ? svg_g4($serial,(int)$j['year']) : svg_g16($serial,(int)$j['year']) ?></div>
<?php endforeach; ?>
</div></body></html>
