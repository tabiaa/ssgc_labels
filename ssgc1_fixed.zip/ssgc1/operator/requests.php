<?php
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/labels.php';
require_once __DIR__.'/../includes/audit.php';
$u=require_role('operator');$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_verify();
 if(($_POST['action']??'')==='print'){
  try{[$job,$r]=authorize_reprint((int)$_POST['request_id'],$u['id']);audit($u['id'],'REPRINT_PRINT_AUTHORIZED','print_job',$job,'approved request');header('Location: '.base_url('operator/print.php?job='.$job));exit;}
  catch(Throwable $e){$err=$e->getMessage();}
 }
}
$rows=list_requests('', $u['id']);$page_title='Reprint Requests';$active_nav='requests';require_once __DIR__.'/../includes/header.php';
?>
<div class="toolbar"><div><h1 style="margin:0;font-size:25px">Reprint Requests</h1><div class="muted">Only approved requests can be consumed, and each approval can be used once.</div></div></div>
<?php if($msg):?><div class="alert alert-success"><?=e($msg)?></div><?php endif;?><?php if($err):?><div class="alert alert-error"><?=e($err)?></div><?php endif;?>
<div class="card" style="padding:0"><div class="table-wrap"><table><thead><tr><th>ID</th><th>Label</th><th>Meter range</th><th>Reason</th><th>Status</th><th>Review</th><th>Action</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr><td>#<?=$r['id']?></td><td><?=e($r['label_type'])?></td><td><code><?=e($r['range_label'])?></code></td><td><?=e(mb_strimwidth($r['reason'],0,60,'…'))?></td><td><span class="status status-<?=e($r['status'])?>"><?=e($r['status'])?></span></td><td class="mini"><?=e($r['admin_name']??'—')?><?= $r['reviewed_at']?' · '.date('d M Y H:i',strtotime($r['reviewed_at'])):''?><br><?=e($r['admin_note']??'')?></td><td><?php if($r['status']==='approved'):?><form method="post"><input type="hidden" name="_csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="print"><input type="hidden" name="request_id" value="<?=$r['id']?>"><button class="btn btn-success" onclick="return confirm('Start the approved reprint?')">Print Now</button></form><?php elseif($r['status']==='used'):?>Completed<?php else:?>—<?php endif;?></td></tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="7" class="empty">No reprint requests.</td></tr><?php endif;?></tbody></table></div></div>
<?php require_once __DIR__.'/../includes/footer.php';?>
