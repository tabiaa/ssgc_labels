<?php
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/labels.php';
require_once __DIR__.'/../includes/audit.php';
require_once __DIR__.'/../includes/barcode.php';

$u = require_role('operator');
$job = (int)($_GET['job'] ?? 0);

$q = db()->prepare('SELECT pj.*,u.full_name FROM print_jobs pj JOIN users u ON u.id=pj.operator_id WHERE pj.id=? AND pj.operator_id=? LIMIT 1');
$q->execute([$job,$u['id']]);
$j = $q->fetch();
if (!$j) { http_response_code(404); exit('Print job not found.'); }

$q = db()->prepare('SELECT serial FROM printed_serials WHERE job_id=? ORDER BY id');
$q->execute([$job]);
$serialList = array_column($q->fetchAll(),'serial');
if (!$serialList && $j['print_kind']==='reprint') {
    $serialList = serials($j['prefix'],(int)$j['range_start'],(int)$j['range_end']);
}
audit($u['id'],'PRINT_PAGE_OPENED','print_job',$job,$j['print_kind']);

function svg_text(string $text, float $x, float $y, float $size, string $weight='700', string $anchor='start'): string {
    return '<text x="'.$x.'" y="'.$y.'" text-anchor="'.$anchor.'" font-family="Arial Narrow,Arial,sans-serif" font-size="'.$size.'px" font-weight="'.$weight.'">'.htmlspecialchars($text,ENT_QUOTES,'UTF-8').'</text>';
}

function logo_svg(float $x, float $y, float $w, float $h): string {
    // Use the actual SSGC logo artwork as a bundled raster image, not a hand-drawn SVG.
    $file = __DIR__.'/../assets/img/ssgc-logo.png';
    $data = is_file($file) ? base64_encode(file_get_contents($file)) : '';
    if (!$data) return '';
    return '<image x="'.$x.'" y="'.$y.'" width="'.$w.'" height="'.$h.'" href="data:image/png;base64,'.$data.'" preserveAspectRatio="xMidYMid meet" />';
}

function svg_g4(string $serial, int $year): string {
    $barcode = code128_svg($serial, 22.0, 29.0, 31.5, 6.8);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 104.1 130" width="104.1mm" height="130mm">'
        .'<g transform="translate(0 130) rotate(-90)">'
        .'<rect width="130" height="104.1" fill="#fff"/>'
        .'<line x1="129.15" y1="20" x2="129.15" y2="104.1" stroke="#000" stroke-width="0.45"/>'
        .'<rect x="64.0" y="22.0" width="4.5" height="4.5" fill="#000"/>'
        .$barcode
        .svg_text('No. '.$serial,20.0,40.0,3.7)
        .svg_text('SUI SOUTHERN GAS CO.LTD.',54.0,35.5,4.15)
        .svg_text('m³',71.0,39.8,4.0,'700','middle')
        .svg_text('G4',13.0,55.0,4.0)
        .svg_text('GAS METER',13.0,60.0,3.8)
        .logo_svg(12.8,61.5,6.5,8.0)
        .svg_text('MADE IN',13.0,79.0,3.6)
        .svg_text('PAKISTAN',13.0,84.0,3.6)
        .svg_text('*Qmax = 6 m³/hr',69.0,57.8,3.35,'400')
        .svg_text('Qmin = 0.04 m³/hr',69.0,62.2,3.35,'400')
        .svg_text('Pmax = 0.5 bar',69.0,66.6,3.35,'400')
        .svg_text('C.V.    = 1.2 dm',69.0,71.0,3.35,'400')
        .'<rect x="107.5" y="52.4" width="9.7" height="5.2" fill="#fff" stroke="#000" stroke-width="0.45"/>'
        .svg_text((string)$year,112.35,56.25,3.65,'700','middle')
        .'</g></svg>';
}

function svg_g16(string $serial, int $year): string {
    $barcode = code128_svg($serial, 15.0, 44.0, 27.0, 7.0);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 90" width="80mm" height="90mm">'
        .'<g transform="translate(0 90) rotate(-90)">'
        .'<rect width="90" height="80" fill="#fff"/>'
        .'<line x1="89.2" y1="12" x2="89.2" y2="80" stroke="#000" stroke-width="0.45"/>'
        .logo_svg(10.8,22.5,5.8,8.0)
        .svg_text('SUI SOUTHERN GAS CO.LTD.',20.0,27.0,4.65)
        .svg_text('G1.6 GAS METER  '.$year.'  MADE IN PAKISTAN',20.0,32.5,3.25)
        // Open rectangular volume marking from the original label.
        .'<path d="M48 34.5 H74.5 V42.2 H48" fill="none" stroke="#000" stroke-width="1.05"/>'
        .svg_text('m³',45.0,46.0,3.5,'700')
        .$barcode
        .svg_text('No. '.$serial,15.0,55.1,3.15)
        // Compact the specification block so the final C.V. line remains inside the cut area.
        .svg_text('Qmax = 2.5 m³/hr',51.0,45.2,2.45,'400')
        .svg_text('Qmin = 0.016 m³/hr',51.0,48.2,2.45,'400')
        .svg_text('Pmax = 0.5 bar',51.0,51.2,2.45,'400')
        .svg_text('C.V. = 0.8 dm³',51.0,54.2,2.45,'400')
        .'</g></svg>';
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Print Job #<?=e((string)$job)?></title>
<link rel="stylesheet" href="<?=e(base_url('assets/css/main.css'))?>">
<style>
@page g4{size:104.1mm 130mm;margin:0}
@page g16{size:80mm 90mm;margin:0}
body{background:#f1f3f5}
.print-toolbar{max-width:1100px;margin:20px auto;padding:16px 20px;background:#fff;border:1px solid #ddd;border-radius:10px;display:flex;align-items:center;justify-content:space-between;gap:20px}
.print-area{display:flex;flex-direction:column;align-items:center;gap:12px;padding:20px}
.label-page{background:#fff;page-break-after:always;break-after:page;position:relative;overflow:hidden}
.label-page.g4{width:104.1mm;height:130mm;page:g4}
.label-page.g16{width:80mm;height:90mm;page:g16}
.label-svg{width:100%;height:100%;display:block;shape-rendering:geometricPrecision;text-rendering:geometricPrecision}
.screen-note{max-width:1100px;margin:0 auto 10px;color:#555;font:13px Arial}
@media print{body{background:#fff;margin:0}.print-toolbar,.screen-note{display:none!important}.print-area{padding:0;display:block}.label-page{margin:0!important;box-shadow:none!important}}
</style></head><body>
<div class="print-toolbar"><div><strong>Print Job #<?=e((string)$job)?></strong><div style="font-size:12px;color:#667;margin-top:4px"><?=e($j['label_type'])?> · <?=e($j['prefix'].str_pad($j['range_start'],4,'0',STR_PAD_LEFT).' – '.$j['prefix'].str_pad($j['range_end'],4,'0',STR_PAD_LEFT))?> · <?=$j['year']?></div></div><div style="display:flex;gap:8px"><button class="btn btn-primary" onclick="window.print()">Print Labels</button><a class="btn btn-ghost" href="<?=e(base_url('operator/dashboard.php'))?>">Back</a></div></div>
<div class="screen-note">Select <strong>TSC TA210</strong>. Set scaling to <strong>100% / Actual Size</strong>, margins <strong>None</strong>, and turn browser headers/footers off. The page is portrait, matching the original PDF print orientation; the label artwork is rotated 90° counter-clockwise inside the page. The barcode is now generated server-side as vector bars inside the SVG.</div>
<div class="print-area">
<?php foreach ($serialList as $serial): ?>
<div class="label-page <?=$j['label_type']==='G4'?'g4':'g16'?>"><?= $j['label_type']==='G4' ? svg_g4($serial,(int)$j['year']) : svg_g16($serial,(int)$j['year']) ?></div>
<?php endforeach; ?>
</div></body></html>
