# SSGC Meter Label Control System — Standalone Vector Edition

This edition does **not** require BarTender. The supplied G-4 and G1.6 BarTender files were used as the visual reference; they are not runtime dependencies.

## Runtime requirements
- Windows Server + IIS
- PHP 8.x with PDO MySQL
- MySQL 5.7+ / MariaDB 10.3+
- Any Windows printer driver; configured for the TSC TA210 in the deployment environment
- Modern browser

## Printing model
The application generates the label as **inline SVG/vector graphics** and opens a browser print page. No PNG/JPEG label background and no BarTender executable are used.

The operator selects the TSC TA210 in the browser print dialog and should use:
- Scale: 100% / Actual size
- Margins: None
- Headers/footers: Off
- Correct paper size for the label

The G-4 print canvas is 130 × 104.1 mm. The G1.6 print canvas is 90 × 80 mm. The dimensions are the rotated physical orientations corresponding to the supplied BTW templates.

## Control model
1. Operator checks a meter range.
2. Server checks the database.
3. A first-print job atomically inserts every meter number under a unique `(serial, year)` key.
4. Only after that successful reservation is the vector print page opened.
5. A meter already protected by a first print cannot be printed again by an operator.
6. Operator submits a reprint reason.
7. Administrator approves/rejects it.
8. An approved request can be consumed once and then becomes `used`.
9. Every important action is written to `audit_log`.

A browser print dialog cannot tell the server whether a physical printer successfully produced the label. For this reason, the application treats the server-side print authorization as the controlled print event. If the printer was offline or a label was physically damaged, the meter remains protected and a normal admin-approved reprint is required. This is deliberate: it prevents accidental duplicate issuance.

## Installation
1. Copy the folder to the IIS web root.
2. Create/import the `ssgc_labels` database using `schema.sql`.
3. Edit `includes/config.php` with MySQL credentials.
4. Ensure PHP has PDO MySQL enabled.
5. Browse to `setup.php` and create the first administrator.
6. Delete or restrict `setup.php` after setup.
7. Log in and create operator accounts.
8. Configure the Windows TSC TA210 printer normally. BarTender is not involved.

## Important
The vector templates intentionally reproduce the supplied BTW artwork as vector text/lines/shapes and generate a fresh Code 128 barcode from the meter number. The original BTW files are not needed by this application and can remain with users who print separately in BarTender.

### Label rendering revision
- G-4 and G1.6 artwork was rebuilt against the supplied BTW label previews rather than the earlier approximate layout.
- Barcodes are generated server-side as Code 128-B SVG bars, so they are true vector output and do not depend on browser JavaScript or an external library.
- The Code 128 pattern table includes the full 0-106 symbol set, including the stop pattern.
- A local bundled SSGC logo SVG is embedded into each printed label so printing does not require internet access.
- Label print sizes remain G-4: 130 x 104.1 mm and G1.6: 90 x 80 mm.


## Meter number format (prefix optional, up to 20 digits)
- The prefix is optional: one letter A-Z, or empty (the meter number is then digits only).
- The number is 1 to 20 digits. It is shown with at least 4 digits (100 becomes 0100); an 8-digit or 20-digit number keeps its own length.
- Start and end must have a valid range, maximum 1000 labels per print job.
- On an **existing** database run `migrate_variable_meter_numbers.sql` once (new installs using `schema.sql` already include it).
- Long numbers use the compact Code 128-C barcode, and the printed number gets a smaller font so it fits the label.

## Desktop-app-only access
`includes/config.php` ends with a block that only lets the "SSGC Label Printing" desktop app use the system (it sends the key `DESKTOP_APP_KEY` in the `X-SSGC-App-Key` header). Browsers get a "use the app" page.
- When updating an existing server, do NOT overwrite its `includes/config.php` (it holds the database login). Paste only the block starting at `// ---- Desktop-app-only access` at the end of the existing file.
- Set `REQUIRE_DESKTOP_APP` to `false` to allow browsers again (for example while testing).
