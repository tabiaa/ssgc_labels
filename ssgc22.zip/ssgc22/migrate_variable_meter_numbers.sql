-- Run ONCE on an existing ssgc_labels database (new installs using schema.sql do not need this).
-- Allows an empty prefix and meter numbers of up to 20 digits.
USE ssgc_labels;

ALTER TABLE print_jobs
  MODIFY prefix CHAR(1) NOT NULL DEFAULT '',
  MODIFY range_start VARCHAR(20) NOT NULL,
  MODIFY range_end VARCHAR(20) NOT NULL;

ALTER TABLE reprint_requests
  MODIFY prefix CHAR(1) NOT NULL DEFAULT '',
  MODIFY range_start VARCHAR(20) NOT NULL,
  MODIFY range_end VARCHAR(20) NOT NULL;

ALTER TABLE printed_serials
  MODIFY serial VARCHAR(32) NOT NULL;

-- Old numbers were stored without leading zeros (100); store them as 4 digits (0100) like the new code does.
UPDATE print_jobs SET
  range_start = IF(CHAR_LENGTH(range_start) < 4, LPAD(range_start, 4, '0'), range_start),
  range_end   = IF(CHAR_LENGTH(range_end)   < 4, LPAD(range_end,   4, '0'), range_end);
UPDATE reprint_requests SET
  range_start = IF(CHAR_LENGTH(range_start) < 4, LPAD(range_start, 4, '0'), range_start),
  range_end   = IF(CHAR_LENGTH(range_end)   < 4, LPAD(range_end,   4, '0'), range_end);
