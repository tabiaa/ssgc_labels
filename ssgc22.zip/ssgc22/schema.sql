CREATE DATABASE IF NOT EXISTS ssgc_labels CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ssgc_labels;
CREATE TABLE IF NOT EXISTS users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('admin','operator') NOT NULL DEFAULT 'operator',
 full_name VARCHAR(100) NOT NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS print_jobs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 operator_id INT UNSIGNED NOT NULL,
 label_type ENUM('G4','G16') NOT NULL,
 prefix CHAR(1) NOT NULL DEFAULT '',
 range_start VARCHAR(20) NOT NULL,
 range_end VARCHAR(20) NOT NULL,
 year SMALLINT UNSIGNED NOT NULL,
 print_kind ENUM('original','reprint') NOT NULL,
 status ENUM('completed','cancelled') NOT NULL DEFAULT 'completed',
 error_message TEXT NULL,
 request_id BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 printed_at DATETIME NULL,
 FOREIGN KEY(operator_id) REFERENCES users(id),
 INDEX ix_jobs_created(created_at),
 INDEX ix_jobs_status(status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS printed_serials (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 serial VARCHAR(32) NOT NULL,
 year SMALLINT UNSIGNED NOT NULL,
 state ENUM('printed') NOT NULL DEFAULT 'printed',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_meter_year(serial,year),
 FOREIGN KEY(job_id) REFERENCES print_jobs(id),
 INDEX ix_serial_year(year,serial)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS reprint_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 operator_id INT UNSIGNED NOT NULL,
 label_type ENUM('G4','G16') NOT NULL,
 prefix CHAR(1) NOT NULL DEFAULT '',
 range_start VARCHAR(20) NOT NULL,
 range_end VARCHAR(20) NOT NULL,
 year SMALLINT UNSIGNED NOT NULL,
 reason VARCHAR(1000) NOT NULL,
 status ENUM('pending','approved','rejected','used') NOT NULL DEFAULT 'pending',
 reviewed_by INT UNSIGNED NULL,
 reviewed_at DATETIME NULL,
 admin_note VARCHAR(1000) NULL,
 requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(operator_id) REFERENCES users(id),
 FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL,
 INDEX ix_rr_status(status,requested_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS audit_log (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NULL,
 action VARCHAR(80) NOT NULL,
 entity_type VARCHAR(50) NULL,
 entity_id BIGINT UNSIGNED NULL,
 details TEXT NULL,
 ip_address VARCHAR(45) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX ix_audit_created(created_at)
) ENGINE=InnoDB;
