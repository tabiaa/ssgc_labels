<?php
// Edit these values for your IIS/MySQL installation.
define('DB_HOST', 'localhost');
define('DB_NAME', 'ssgc_labels');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');
define('APP_NAME', 'SSGC Meter Label Control System');
define('SESSION_NAME', 'ssgc_meter_label');
define('SESSION_TIMEOUT', 1800);
date_default_timezone_set('Asia/Karachi');

// ---- Desktop-app-only access --------------------------------------------------------------
// Only the "SSGC Label Printing" desktop app (which sends this key in a header) may use the system.
// Browsers (Chrome, Edge ...) get a "use the app" page. Set REQUIRE_DESKTOP_APP to false to allow browsers again.
// The same key must be in the app's config.json ("appKey"). Change both together to rotate it.
define('REQUIRE_DESKTOP_APP', true);
define('DESKTOP_APP_KEY', '16978dc847f86ff16e60125f4bdd50a68540b4057be2dd09');
function ssgc_require_desktop_app(bool $cliAllowed = true): void {
    if (!REQUIRE_DESKTOP_APP || ($cliAllowed && PHP_SAPI === 'cli')) return;
    $sent = $_SERVER['HTTP_X_SSGC_APP_KEY'] ?? '';
    if (is_string($sent) && hash_equals(DESKTOP_APP_KEY, $sent)) return;
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset="utf-8"><title>Use the desktop app</title>'
        .'<body style="font:18px Arial;padding:60px;color:#222"><h2>Please use the SSGC Label Printing app</h2>'
        .'<p>This system can only be opened from the SSGC Label Printing desktop application, not from a web browser.</p></body>';
    exit;
}
ssgc_require_desktop_app();
