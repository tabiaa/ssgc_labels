<?php
/** Code 128-B barcode rendered directly as SVG rectangles. No external JS/library. */
/** Code 128 symbol patterns (index = symbol value 0-106). */
function code128_patterns(): array {
    static $p = null;
    if ($p === null) {
        $p = ['212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232','2331112'];
    }
    return $p;
}

/**
 * Symbol values for $text. Uses Code 128-B, and switches to the compact Code 128-C for a run of
 * 6 or more trailing digits (long meter numbers stay narrow enough to print and scan).
 * Shorter serials such as A0353 are encoded exactly as before.
 */
function code128_values(string $text): array {
    $len = strlen($text);
    for ($i=0; $i<$len; $i++) {
        $o = ord($text[$i]);
        if ($o < 32 || $o > 127) throw new InvalidArgumentException('Code 128-B supports ASCII 32-127 only.');
    }
    $n = 0;
    while ($n < $len && ctype_digit($text[$len-1-$n])) $n++;
    $k = $n >= 6 ? $n - ($n % 2) : 0;   // digits encoded in subset C (always an even count)
    $bLen = $len - $k;
    if ($k > 0 && $bLen === 0) {
        $values = [105];
    } else {
        $values = [104];
        for ($i=0; $i<$bLen; $i++) $values[] = ord($text[$i]) - 32;
        if ($k > 0) $values[] = 99;
    }
    for ($i=$bLen; $i<$len; $i+=2) $values[] = (int)substr($text, $i, 2);
    $sum = $values[0];
    for ($i=1; $i<count($values); $i++) $sum += $values[$i] * $i;
    $values[] = $sum % 103;
    $values[] = 106;
    return $values;
}

function code128_modules(string $text): int {
    $patterns = code128_patterns();
    $modules = 0;
    foreach (code128_values($text) as $v) foreach (str_split($patterns[$v]) as $n) $modules += (int)$n;
    return $modules;
}

function code128_svg(string $text, float $x, float $y, float $width, float $height): string {
    $patterns = code128_patterns();
    $values = code128_values($text);
    $modules = 0;
    foreach ($values as $v) foreach (str_split($patterns[$v]) as $n) $modules += (int)$n;
    $module = $width / $modules;
    $cursor = $x;
    $black = true;
    $out = '<g shape-rendering="crispEdges">';
    foreach ($values as $v) {
        foreach (str_split($patterns[$v]) as $n) {
            $w = (int)$n * $module;
            if ($black) {
                $out .= '<rect x="'.rtrim(rtrim(number_format($cursor,3,'.',''),'0'),'.').'" y="'.rtrim(rtrim(number_format($y,3,'.',''),'0'),'.').'" width="'.rtrim(rtrim(number_format($w,3,'.',''),'0'),'.').'" height="'.rtrim(rtrim(number_format($height,3,'.',''),'0'),'.').'" fill="#000"/>';
            }
            $cursor += $w;
            $black = !$black;
        }
    }
    return $out.'</g>';
}
