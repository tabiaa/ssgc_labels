<?php
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/labels.php';
require_once __DIR__.'/../includes/audit.php';
require_once __DIR__.'/../includes/barcode.php';

$u = require_role('operator');
$job = (int)($_GET['job'] ?? 0);

$q = db()->prepare('SELECT pj.*,u.full_name FROM print_jobs pj JOIN users u ON u.id=pj.operator_id WHERE pj.id=? AND pj.operator_id=? LIMIT 1');
$q->execute([$job,$u['id']]);
$j = $q->fetch();
if (!$j) { http_response_code(404); exit('Print job not found.'); }

$q = db()->prepare('SELECT serial FROM printed_serials WHERE job_id=? ORDER BY id');
$q->execute([$job]);
$serialList = array_column($q->fetchAll(),'serial');
if (!$serialList && $j['print_kind']==='reprint') {
    $serialList = serials($j['prefix'],(string)$j['range_start'],(string)$j['range_end']);
}
audit($u['id'],'PRINT_PAGE_OPENED','print_job',$job,$j['print_kind']);

function svg_text(string $text, float $x, float $y, float $size, string $weight='700', string $anchor='start', ?float $len=null, float $thin=0.0): string {
    $fit = $len !== null ? ' textLength="'.$len.'" lengthAdjust="spacingAndGlyphs"' : '';
    // $thin > 0 draws a thin white outline over the glyphs, which makes the text visibly lighter when printed.
    $thinAttr = $thin > 0 ? ' stroke="#fff" stroke-width="'.$thin.'" stroke-linejoin="round"' : '';
    return '<text x="'.$x.'" y="'.$y.'" text-anchor="'.$anchor.'" font-family="Arial Narrow,Arial,sans-serif" font-size="'.$size.'px" font-weight="'.$weight.'"'.$thinAttr.$fit.'>'.htmlspecialchars($text,ENT_QUOTES,'UTF-8').'</text>';
}

function logo_svg(float $x, float $y, float $w, float $h): string {
    // Use the actual SSGC logo artwork as a bundled raster image, not a hand-drawn SVG.
    $file = __DIR__.'/../assets/img/ssgc-logo.png';
    $data = is_file($file) ? base64_encode(file_get_contents($file)) : '';
    if (!$data) return '';
    return '<image x="'.$x.'" y="'.$y.'" width="'.$w.'" height="'.$h.'" href="data:image/png;base64,'.$data.'" preserveAspectRatio="xMidYMid meet" />';
}

function logo_flame_svg(float $x, float $y, float $w, float $h): string {
    // Black-and-white SSGC flame as vector paths (prints crisp, with the pointed tip).
    // ($x,$y,$w,$h) is the box of the flame body; the tip extends a little above $y.
    $sx = $w / (113 - 36);
    $sy = $h / 120;
    $tx = $x - 36 * $sx;
    return '<g transform="translate('.round($tx,4).' '.round($y,4).') scale('.round($sx,5).' '.round($sy,5).')">'
        .'<path d="M84.88 -21.25 L83.88 -20.50 L82.50 -18.75 L79.88 -16.12 L68.00 -6.75 L62.75 -1.12 L62.00 0.50 L61.00 1.38 L60.88 2.62 L57.00 6.38 L56.88 7.62 L55.00 9.38 L54.88 10.62 L53.00 12.38 L52.88 13.62 L51.00 15.38 L50.88 16.62 L49.00 18.38 L49.00 19.38 L48.00 20.38 L48.00 21.38 L47.00 22.38 L47.00 23.38 L46.00 24.38 L45.88 25.62 L44.00 27.38 L44.00 29.38 L43.00 30.38 L43.00 31.38 L42.00 32.38 L41.88 33.62 L41.00 34.38 L41.00 36.38 L40.00 37.38 L40.00 39.38 L39.00 40.38 L39.00 43.38 L38.00 44.38 L38.00 47.38 L37.00 48.38 L37.00 53.38 L36.00 54.38 L36.00 71.50 L37.00 72.50 L37.00 78.50 L38.00 79.50 L38.00 82.50 L39.00 83.50 L39.00 86.50 L40.00 87.50 L40.00 90.50 L41.00 91.50 L41.00 93.50 L42.00 94.50 L42.00 96.50 L43.00 97.50 L43.00 99.50 L43.88 100.25 L44.00 101.50 L44.88 102.25 L45.00 103.50 L46.00 104.50 L46.00 106.50 L46.88 107.25 L47.00 108.50 L47.88 109.25 L48.00 110.50 L48.88 111.25 L49.00 112.50 L49.88 113.25 L50.00 114.50 L51.00 115.50 L51.00 116.50 L53.00 118.50 L53.00 119.88 L87.88 119.88 L88.00 119.25 L91.88 115.50 L92.00 114.25 L95.88 110.50 L96.00 109.25 L97.88 107.50 L98.00 106.25 L99.88 104.50 L99.88 103.50 L100.88 102.50 L100.88 101.50 L101.88 100.50 L101.88 99.50 L102.88 98.50 L103.00 97.25 L104.88 95.50 L104.88 94.50 L105.88 93.50 L105.88 92.50 L106.88 91.50 L107.00 90.25 L107.88 89.50 L107.88 87.50 L108.88 86.50 L108.88 85.50 L109.88 84.50 L109.88 82.50 L110.88 81.50 L110.88 77.50 L111.88 76.50 L111.88 70.50 L112.88 69.50 L112.88 66.38 L111.88 65.38 L111.88 60.38 L110.88 59.38 L110.88 55.38 L109.88 54.38 L109.88 52.38 L109.00 51.62 L108.88 50.38 L107.88 49.38 L107.88 47.38 L107.00 46.62 L106.88 45.38 L106.00 44.62 L105.88 43.38 L105.00 42.62 L104.88 41.38 L103.88 40.38 L103.88 39.38 L101.00 36.62 L100.88 35.38 L99.88 34.38 L99.88 33.38 L98.00 31.62 L97.88 30.38 L96.00 28.62 L95.88 27.38 L95.00 26.62 L94.88 25.38 L93.00 23.62 L92.88 22.38 L91.88 21.38 L91.88 19.38 L91.00 18.62 L90.88 17.38 L89.88 16.38 L89.88 14.38 L89.00 13.62 L88.88 11.38 L87.88 10.38 L87.88 7.38 L86.88 6.38 L86.88 2.38 L86.25 1.50 L85.88 -7.38 L85.00 -15.25Z" fill="#000"/>'
        .'<path d="M68.38 19.00 L62.00 25.38 L61.88 26.62 L60.00 28.38 L59.88 29.62 L58.00 31.38 L57.88 32.62 L56.00 34.38 L56.00 35.38 L55.00 36.38 L55.00 37.38 L54.00 38.38 L54.00 39.38 L53.00 40.38 L53.00 41.38 L52.00 42.38 L51.88 43.62 L51.00 44.38 L51.00 46.38 L50.00 47.38 L49.88 48.62 L49.00 49.38 L49.00 52.38 L48.00 53.38 L48.00 55.38 L47.00 56.38 L47.00 60.38 L46.00 61.38 L46.00 67.38 L45.00 68.38 L45.00 82.50 L46.00 83.50 L46.00 89.50 L47.00 90.50 L47.00 93.50 L47.88 94.25 L48.00 96.50 L49.00 97.50 L49.00 100.50 L49.88 101.25 L50.00 103.50 L50.88 104.25 L51.00 105.50 L52.00 106.50 L52.00 108.50 L52.88 109.25 L53.00 110.50 L54.00 111.50 L54.00 113.50 L54.88 114.25 L55.00 115.50 L55.88 116.25 L56.00 117.50 L57.00 118.50 L57.00 119.88 L59.88 119.88 L59.88 119.38 L58.88 118.38 L58.88 117.38 L57.88 116.38 L57.88 114.38 L57.00 113.62 L56.88 111.38 L55.88 110.38 L55.88 107.38 L54.88 106.38 L54.88 103.38 L53.88 102.38 L53.88 96.38 L52.88 95.38 L52.88 82.50 L53.88 81.50 L53.88 76.50 L54.88 75.50 L54.88 72.50 L55.88 71.50 L55.88 68.50 L56.88 67.50 L56.88 65.50 L57.88 64.50 L57.88 62.50 L58.88 61.50 L58.88 59.50 L59.88 58.50 L59.88 57.50 L60.88 56.50 L61.00 55.25 L61.88 54.50 L61.88 52.50 L62.88 51.50 L63.00 50.25 L64.88 48.50 L64.88 47.50 L65.88 46.50 L65.88 45.50 L66.25 45.00 L67.38 44.88 L68.38 45.88 L69.62 46.00 L70.00 46.50 L70.00 47.50 L73.88 51.25 L74.00 52.50 L76.88 55.25 L77.00 56.50 L78.00 57.50 L78.00 58.50 L79.88 60.25 L80.00 61.50 L81.00 62.50 L81.00 64.50 L81.88 65.25 L82.00 66.50 L83.00 67.50 L83.00 70.50 L83.88 71.25 L84.00 73.50 L85.00 74.50 L85.00 78.50 L86.00 79.50 L86.00 86.50 L87.00 87.50 L87.00 97.38 L86.00 98.38 L86.00 104.38 L85.00 105.38 L85.00 109.38 L84.00 110.38 L84.00 112.38 L83.00 113.38 L83.00 115.38 L82.00 116.38 L82.00 118.38 L81.00 119.38 L81.00 119.88 L82.88 119.88 L83.00 119.25 L83.88 118.50 L84.00 117.25 L84.88 116.50 L85.00 115.25 L85.88 114.50 L86.00 113.25 L86.88 112.50 L86.88 110.50 L87.88 109.50 L88.00 108.25 L88.88 107.50 L88.88 105.50 L89.88 104.50 L89.88 102.50 L90.88 101.50 L90.88 99.50 L91.88 98.50 L91.88 95.50 L92.88 94.50 L92.88 91.50 L93.88 90.50 L93.88 85.50 L94.88 84.50 L94.88 63.38 L93.88 62.38 L93.88 58.38 L92.88 57.38 L92.88 54.38 L91.88 53.38 L91.88 51.38 L90.88 50.38 L90.88 48.38 L90.00 47.62 L89.88 46.38 L89.00 45.62 L88.88 44.38 L88.00 43.62 L87.88 42.38 L87.00 41.62 L86.88 40.38 L85.88 39.38 L85.88 38.38 L84.00 36.62 L83.88 35.38 L82.88 34.38 L82.88 33.38 L80.00 30.62 L79.88 29.38 L69.50 19.00Z" fill="#fff"/>'
        .'<path d="M67.25 45.12 L65.00 47.38 L65.00 48.38 L64.00 49.38 L64.00 50.38 L63.00 51.38 L62.88 52.62 L62.00 53.38 L62.00 55.38 L61.00 56.38 L61.00 57.38 L60.00 58.38 L59.88 59.62 L59.00 60.38 L59.00 62.38 L58.00 63.38 L58.00 65.38 L57.00 66.38 L57.00 68.38 L56.00 69.38 L56.00 72.38 L55.00 73.38 L55.00 78.38 L54.00 79.38 L54.00 99.50 L55.00 100.50 L55.00 105.50 L56.00 106.50 L56.00 109.50 L57.00 110.50 L57.00 112.50 L58.00 113.50 L58.00 115.50 L58.88 116.25 L59.00 117.50 L60.00 118.50 L60.00 119.88 L80.88 119.88 L80.88 118.50 L81.88 117.50 L81.88 115.50 L82.88 114.50 L82.88 112.50 L83.88 111.50 L83.88 107.50 L84.88 106.50 L84.88 103.50 L85.88 102.50 L85.88 82.38 L84.88 81.38 L84.88 76.38 L83.88 75.38 L83.88 72.38 L82.88 71.38 L82.88 69.38 L81.88 68.38 L81.88 66.38 L81.00 65.62 L80.88 64.38 L79.88 63.38 L79.88 61.38 L79.00 60.62 L78.88 59.38 L77.00 57.62 L76.88 56.38 L75.00 54.62 L74.88 53.38 L73.00 51.62 L72.88 50.38 L67.62 45.12Z" fill="#000"/>'
        .'</g>';
}

/** Barcode width: the usual width for short serials, a little wider (up to $max) for long ones so bars stay printable. */
function barcode_width(string $serial, float $min, float $max): float {
    return max($min, min($max, code128_modules($serial) * 0.2));
}

/** Text size that keeps $text inside $maxWidth mm (long meter numbers get a smaller font; short ones keep $size). */
function fit_size(string $text, float $size, float $maxWidth): float {
    return min($size, round($maxWidth / (max(1, strlen($text)) * 0.56), 2));
}

function svg_g4(string $serial, int $year): string {
    // Layout measured from the scanned correct G-4 print (mm, label orientation).
    // Fine-tune the whole G-4 print against the die cut here:
    // +$dx moves everything toward the right of the finished label, +$dy moves everything down.
    $dx = 2.3;
    $dy = 1.2;
    // Black sensor mark is drawn separately from the artwork, so $dx/$dy do not move it.
    // It sits 0.2in (5.08mm) further back than before, so its centre reads 2.5in instead of 2.7in.
    $markX = 66.22;
    $markY = 21.3; // 1mm lower than the previous 20.3
    $barcode = code128_svg($serial, 29.4, 30.8, barcode_width($serial, 20.2, 21.0), 5.4);
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 104.1 130" width="104.1mm" height="130mm">'
        .'<g transform="translate(0 130) rotate(-90)">'
        .'<rect width="130" height="104.1" fill="#fff"/>'
        .'<line x1="129.15" y1="20" x2="129.15" y2="104.1" stroke="#000" stroke-width="0.45"/>'
        .'<rect x="'.$markX.'" y="'.$markY.'" width="4.4" height="3.9" fill="#000"/>'
        .'<g transform="translate('.$dx.' '.$dy.')">'
        .$barcode
        .svg_text('No.',28.4,39.8,3.3)
        .svg_text($serial,33.7,40.1,fit_size($serial,3.8,32.0))
        .svg_text('SUI SOUTHERN GAS CO.LTD.',51.8,36.2,3.9,'700','start',47.6)
        .svg_text('m',68.0,40.2,4.2,'700')
        .svg_text('3',71.0,38.6,2.3,'700')
        .svg_text('G-4',22.6,48.4,3.85,'700','middle')
        .svg_text('GAS METER',13.5,52.7,3.7,'700','start',15.4)
        .logo_flame_svg(13.75,55.1,3.0,4.8)
        .svg_text('SSGC',15.25,63.3,3.7,'700','middle',7.1)
        .svg_text('MADE IN',13.5,69.4,4.05,'700','start',12.3)
        .svg_text('PAKISTAN',13.5,73.8,4.1,'700','start',14.1)
        .svg_text('*Qmax',69.5,54.0,2.8,'700','start',6.3)
        .svg_text('= 6 m³ /hr',77.5,54.0,2.8,'700','start',10.6)
        .svg_text('Qmin',70.3,57.5,2.8,'700','start',5.0)
        .svg_text('= 0.04 m³/hr',77.8,57.5,2.8,'700','start',13.0)
        .svg_text('Pmax',70.3,61.0,2.8,'700','start',5.5)
        .svg_text('= 0.5 bar',78.3,61.0,2.8,'700','start',9.4)
        .svg_text('C.V.',70.3,64.4,2.8,'700','start',3.9)
        .svg_text('= 1.2 dm³',78.9,64.4,2.8,'700','start',10.3)
        .'<rect x="100.2" y="44.4" width="12.05" height="4.65" fill="#fff" stroke="#000" stroke-width="0.45"/>'
        .svg_text((string)$year,106.45,48.4,3.8,'700','middle')
        .'</g>'
        .'</g></svg>';
    // Slightly bolder text on G-4: hairline black outline (0.05 mm = the smallest step). Set to 0 to remove.
    $g4Boost = 0.05;
    return $g4Boost > 0 ? str_replace('<text ','<text stroke="#000" stroke-width="'.$g4Boost.'" stroke-linejoin="round" ',$svg) : $svg;
}

function svg_g16(string $serial, int $year): string {
    $barcode = code128_svg($serial, 15.0, 45.2, barcode_width($serial, 25.0, 26.0), 5.2);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 90" width="80mm" height="90mm">'
        .'<g transform="translate(0 90) rotate(-90)">'
        .'<rect width="90" height="80" fill="#fff"/>'
        .'<line x1="89.2" y1="12" x2="89.2" y2="80" stroke="#000" stroke-width="0.7"/>'
        .logo_flame_svg(12.55,25.76,2.3,3.6)
        .svg_text('SSGC',13.7,31.7,2.6,'700','middle',5.2)
        .'<g class="g16-h">'.svg_text('SUI SOUTHERN GAS CO.LTD.',20.0,28.4,4.65).'</g>'
        // Sub line is centred under the heading (centre of the heading = 20.0 + 54.1/2). The small script at the
        // bottom of the page re-centres it on the heading's real width if the printer PC uses a different font.
        .'<g class="g16-s">'.svg_text('G1.6 GAS METER  '.$year.'  MADE IN PAKISTAN',47.06,32.2,2.8,'700','middle').'</g>'
        // Open rectangular volume marking from the original label.
        .'<path d="M48 34.5 H74.5 V42.2 H48" fill="none" stroke="#000" stroke-width="1.3"/>'
        // "m" in a black square with white lettering; the small 3 stays outside the square.
        .'<rect x="44.5" y="44.2" width="3.4" height="3.4" fill="#000"/>'
        .'<text x="46.2" y="46.7" text-anchor="middle" font-family="Arial Narrow,Arial,sans-serif" font-size="2.9px" font-weight="700" fill="#fff">m</text>'
        .svg_text('3',48.2,44.3,2.0,'700')
        .$barcode
        // Meter number: bigger, normal bold weight (no outline).
        .svg_text('No. '.$serial,15.0,53.7,fit_size('No. '.$serial,3.9,35.0),'700')
        // Spec block: plain regular weight (no outline), size 2.7.
        .svg_text('Qmax = 2.5 m³/hr',51.0,45.0,2.7,'400')
        .svg_text('Qmin = 0.016 m³/hr',51.0,48.1,2.7,'400')
        .svg_text('Pmax = 0.5 bar',51.0,51.2,2.7,'400')
        .svg_text('C.V. = 0.8 dm³',51.0,54.3,2.7,'400')
        .'</g></svg>';
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Print Job #<?=e((string)$job)?></title>
<link rel="stylesheet" href="<?=e(base_url('assets/css/main.css'))?>">
<style>@page{size:<?= $j['label_type']==='G4' ? '104.1mm 130mm' : '82.55mm 89.92mm' ?>;margin:0}</style>
<style>
html,body{margin:0;padding:0}
body{background:#f1f3f5}
.print-toolbar{max-width:1100px;margin:20px auto;padding:16px 20px;background:#fff;border:1px solid #ddd;border-radius:10px;display:flex;align-items:center;justify-content:space-between;gap:20px}
.print-area{display:flex;flex-direction:column;align-items:center;gap:12px;padding:20px}
.screen-note{max-width:1100px;margin:0 auto 10px;color:#555;font:13px Arial}
/* Label box is 0.2mm shorter than the page so rounding can never push content onto a blank extra page. */
.label-page{background:#fff;position:relative;overflow:hidden;break-inside:avoid;page-break-inside:avoid;break-after:page;page-break-after:always}
.label-page svg{display:block;shape-rendering:geometricPrecision;text-rendering:geometricPrecision}
.label-page.g4{width:104.1mm;height:129.8mm}
.label-page.g16{width:82.55mm;height:89.7mm}
@media print{
  body{background:#fff}
  .print-toolbar,.screen-note{display:none!important}
  .print-area{display:block;padding:0}
  .label-page{margin:0!important;box-shadow:none!important}
  .label-page:last-child{break-after:auto;page-break-after:auto}
}
</style></head><body>
<div class="print-toolbar"><div><strong>Print Job #<?=e((string)$job)?></strong><div style="font-size:12px;color:#667;margin-top:4px"><?=e($j['label_type'])?> · <?=e($serialList ? $serialList[0].' – '.$serialList[count($serialList)-1] : '')?> · <?=$j['year']?></div></div><div style="display:flex;gap:8px"><button class="btn btn-primary" onclick="window.print()">Print Labels</button><a class="btn btn-ghost" href="<?=e(base_url('operator/dashboard.php'))?>">Back</a></div></div>
<div class="screen-note">Select <strong>TSC TA210</strong>. Set scaling to <strong>100% / Actual Size</strong>, margins <strong>None</strong>, and turn browser headers/footers off. The page is portrait, matching the original PDF print orientation; the label artwork is rotated 90° counter-clockwise inside the page. The barcode is now generated server-side as vector bars inside the SVG.</div>
<div class="print-area">
<?php foreach ($serialList as $serial): ?>
<div class="label-page <?=$j['label_type']==='G4'?'g4':'g16'?>"><?= $j['label_type']==='G4' ? svg_g4($serial,(int)$j['year']) : svg_g16($serial,(int)$j['year']) ?></div>
<?php endforeach; ?>
</div>
<script>document.querySelectorAll('svg').forEach(function(v){var h=v.querySelector('.g16-h text'),t=v.querySelector('.g16-s text');if(h&&t){var b=h.getBBox();t.setAttribute('x',(b.x+b.width/2).toFixed(3));t.setAttribute('text-anchor','middle');}});</script></body></html>
